<?php

return [
    'name' => 'LoanAgent',
];
