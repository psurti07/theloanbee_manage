<?php

return [
    'name' => 'CompanyLeads',
];
