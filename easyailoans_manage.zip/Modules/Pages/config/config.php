<?php

return [
    'name' => 'Pages',
];
