<?php

return [
    'name' => 'Banks',
];
