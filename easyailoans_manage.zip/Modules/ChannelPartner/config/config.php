<?php

return [
    'name' => 'ChannelPartner',
];
