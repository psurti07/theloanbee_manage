<?php

return [
    'name' => 'Loan',
];
