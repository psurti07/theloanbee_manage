<?php

return [
    'name' => 'Customer',
];
