<?php

return [
    'name' => 'Reports',
];
