<?php

return [
    'name' => 'SiteOptions',
];
