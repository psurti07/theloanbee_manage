<?php

return [
    'name' => 'NewsLetter',
];
